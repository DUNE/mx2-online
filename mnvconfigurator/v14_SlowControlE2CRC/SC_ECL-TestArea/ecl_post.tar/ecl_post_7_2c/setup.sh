export PYTHONPATH=$PYTHONPATH:~/cmtuser/Minerva_v10r9p1/Tools/ControlRoomTools/automated_ecl/ecl_post_7_2c/lib
