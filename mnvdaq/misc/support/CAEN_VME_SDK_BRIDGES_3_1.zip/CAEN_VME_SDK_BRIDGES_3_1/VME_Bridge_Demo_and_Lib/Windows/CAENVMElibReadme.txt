    -----------------------------------------------------------------------------

                   --- CAEN SpA - Computing Systems Division --- 

    -----------------------------------------------------------------------------

    CAENVME Library Rel. 2.7 
    
    Installation and Use Instructions

    -----------------------------------------------------------------------------

    September 2007

    -----------------------------------------------------------------------------


  
 The complete documentation can be found in the CAENVME Library Manual
 available on this CD or on CAEN's Web Site at http://www.caen.it.


 Content 
 -------

 CAENVMELibReadme.txt          :  This file.

 CAENVMELibReleaseNotes.txt    :  Release Notes of the last software release.

 CAENVMEDemoDotNetSetup.exe    :  Install wizard for the CAENVMEDemoDotNet application.

 CAENVMEDotNetWrapperSetup.exe :  Install wizard for the CAENVMEDotNetWrapper library.
 
 CAENVMELibSetup.exe           :  Install wizard for the CAENVMELib library.
 
 Driver                        :  Directory for the driver's binaries.

 Upgrade                       :  Directory containing a console application for 
                                the firmware upgrade of the CAEN V1718/V2718 modules.
                                 
 LabView-6.0                   :  Directory containg the LabView library of VIs.
 

 System Requirements
 -------------------
 
 - CAEN V1718 USB-VME Bridge and/or CAEN A2818 PCI-CONET Board
 - Windows 2000/XP/Vista
 - Microsoft .NET framework 1.1 or later (for CAENVMEDemo and CAENVMELibDotNetWrapper only)


 Installation notes
 ------------------
 
 - Run the CAENVMELibSetup.exe setup program.
 
 - Plug the USB Cable connected to the CAEN V1718 to the PC and switch on the board or 
   plug the A2818 PCI board in your PC.
  
 - Run the CAENVMEDotNetWrapperSetup.exe setup program to install the CAENVMEDotNetWrapper library.
 
 - Run the CAENVMEDemoDotNetSetup.exe setup program to install the CAENVMEDemoDotNet application.
    

 Note
 ----
 
 CAEN A2718 PCI-CONET Board Windows driver is based on PLX API libraries.
 Copyright (c) 2003 PLX Technology, Inc.
